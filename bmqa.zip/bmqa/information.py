token = "7962314645:AAFECynKGWblzc5eKq81iuIlLEZehN3eujo"
owner_id = 125205235